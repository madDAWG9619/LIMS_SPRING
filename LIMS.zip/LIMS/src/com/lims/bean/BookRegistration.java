package com.lims.bean;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class BookRegistration {
	
	@Id
	@GeneratedValue
	@Column(name="registration_id")
	private int registrationId;
	
	@Column(name="user_id")
	private int userId;
	@Column(name="registrationdate")
	private Date registrationDate;
	
	@OneToOne
	@JoinColumn(name="USER_ID")
	private Users userID;
	
	public Users getUserID() {
		return userID;
	}
	public void setUserID(Users userID) {
		this.userID = userID;
	}
	public BooksInventory getBookId() {
		return bookId;
	}
	public void setBookId(BooksInventory bookId) {
		this.bookId = bookId;
	}
	
	@OneToOne
	@JoinColumn(name="BOOK_ID")
	private BooksInventory bookId;
	
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	
	

}

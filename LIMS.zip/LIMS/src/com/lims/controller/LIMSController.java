package com.lims.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;
import com.lims.service.ILIMSService;

@Controller
public class LIMSController {
	
	@Autowired
	ILIMSService service;
	
	
	
	
	/*------------------------------------------------------------
	Method to go to index page (Homepage)
	------------------------------------------------------------*/
	@RequestMapping("index")
	public String indexPage(Model m,@ModelAttribute("obj") Users usr)
	{
		
		m.addAttribute(usr);
		
		return "index";
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to user login (User Login Page)
	------------------------------------------------------------*/
	@RequestMapping("userLogin")
	public String userLoginPage(Model m,@ModelAttribute("obj") Users usr)
	{
		
		m.addAttribute(usr);
		
		return "userLogin";
	}
	//-----------------------------------------------------------

	
	
	
	/*------------------------------------------------------------
	Method to user login (User Login Page)
	------------------------------------------------------------*/
	@RequestMapping("redirectLogin")
	public String redirectLogin(Model m,@ModelAttribute("obj") Users usr)
	{
		
		m.addAttribute(usr);
		String msg = service.register(usr);
		
		return "userLogin";
	}
	//-----------------------------------------------------------
	
	
	
	/*------------------------------------------------------------
	Method to admin login (Admin Login Page)
	------------------------------------------------------------*/
	@RequestMapping("librarianLogin")
	public String adminLoginPage(Model m,@ModelAttribute("obj") Users usr)
	{
		
		m.addAttribute(usr);
		
		return "librarianLogin";
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to register (Register Page)
	------------------------------------------------------------*/
	@RequestMapping("register")
	public String registerPage(Model m,@ModelAttribute("obj") Users usr)
	{
		
		m.addAttribute(usr);
		
		return "register";
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to go to User's content page (User Content Page)
	------------------------------------------------------------*/
	@RequestMapping("userContent")
	public String userContentPage(Model m,@ModelAttribute("obj") Users usr)
	{
		
		System.out.println("-------------In userContent()------------------------------------------------------------------------");
		String target = null;
		m.addAttribute(usr);
		m.addAttribute("usr",usr.getUserName());
		m.addAttribute("pass",usr.getPassword());
		boolean val = service.userLogin(usr.getUserName(), usr.getPassword() , usr);
		if(val)
		{
			target = "userContent";
			
		}
		else
		{
			target = "userLogin";
			m.addAttribute("status","Login Unsuccessful");
		}
		
		return target;
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's content page (Librarian Content Page)
	------------------------------------------------------------*/
	@RequestMapping("librarianContent")
	public String LibrarianContentPage(Model m,@ModelAttribute("obj") Users usr)
	{
		
		String target = null;

		m.addAttribute(usr);
		m.addAttribute("user",usr.getUserName());
		m.addAttribute("pass",usr.getPassword());
		boolean val = service.adminLogin(usr.getUserName(), usr.getPassword() , usr);
		if(val)
		{
			m.addAttribute(new BooksInventory());
			target = "librarianContent";
			
		}
		else
		{
			target = "librarianLogin";
			m.addAttribute("status","Login Unsuccessful");
		}
		
		return target;
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to go to User's View Book Page (Librarian View Book Page)
	------------------------------------------------------------*/
	@RequestMapping("userViewBooks")
	public String userViewbooks(Model m,BooksInventory inventory)
	{
		
		ArrayList<BooksInventory> list = service.view(inventory);
		m.addAttribute("list",list);
		
		return "userViewBooks";
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to go to User's Return Book Page (Librarian return Book Page)
	------------------------------------------------------------*/
	@RequestMapping("userReturn")
	public String userReturn(Model m,BooksInventory inventory)
	{
		
		return "userReturn";
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Books Page (Librarian View Books Page)
	------------------------------------------------------------*/
	@RequestMapping("librarianViewBooks")
	public String librarianViewBooks(Model m,BooksInventory inventory)
	{
		
		ArrayList<BooksInventory> list = service.view(inventory);
		m.addAttribute("list",list);
		
		return "librarianViewBooks";
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's Add Book page (Librarian Add Book Page)
	------------------------------------------------------------*/
	@RequestMapping("librarianAddBooks")
	public String librarianAddBooks(Model m)
	{
		
		m.addAttribute("obj1",new BooksInventory());
		
		return "librarianAddBooks";
	}
	//-----------------------------------------------------------
	
	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Request page (Librarian View Request Page)
	------------------------------------------------------------*/
	@RequestMapping("librarianViewRequest")
	public String librarianViewRequest(Model m,@ModelAttribute("obj") Users usr)
	{
		m.addAttribute(usr);
		
		return "librarianViewRequest";
	}
	//-----------------------------------------------------------

	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Request page (Librarian View Request Page)
	------------------------------------------------------------*/
	@RequestMapping("librarianUpdate")
	public String librarianUpdate(Model m)
	{
		m.addAttribute("obj2",new BooksInventory());
		
		return "librarianSearchById";
	}
	//-----------------------------------------------------------

	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Request page (Librarian View Request Page)
	------------------------------------------------------------*/
	@RequestMapping("deleteDetails")
	public String librarianDelete(Model m,@RequestParam("id")int id)
	{
		String target=null;
		int result;
		result=service.deleteBook(id);
		if(result>0)
		{
			m.addAttribute("msg","Book details updated Successfully");
			target="librarianContent";
		}
		else
		{
			target="librarianDeleteById";
			m.addAttribute("msg","Cannot find such book to delete");
		}
		return target;
	}
	//-----------------------------------------------------------
	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Request page (Librarian View Request Page)
	------------------------------------------------------------*/
	@RequestMapping("updateSearch")
	public String librarianUpdateSearch(Model m,@ModelAttribute("obj2") BooksInventory inventory)
	{
		String target=null;
		int booksearchId=inventory.getBookId();
		BooksInventory result=service.updateSearchBook(booksearchId);
		if(result==null)
		{
			target="librarianSearchById";
			m.addAttribute("msg","No such book Available");
		}
		else
		{
			System.out.println("In controller");
			target="librarianUpdate";	
		}
		return target;
		
	}
	//-----------------------------------------------------------

	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Request page (Librarian View Request Page)
	------------------------------------------------------------*/
	@RequestMapping("UpdatedDetails")
	public String librarianUpdate(Model m,@ModelAttribute("obj2") BooksInventory inventory)
	{
		System.out.println("---------------------------------Working-------------------------");
		String target=null;
		int id=service.updateBook(inventory);
		if(id>0)
		{
			target="librarianContent";
		}
		else
		{
			m.addAttribute("msg","Update unsuccessful");
			target="librarianSearchById";
		}
		return target;
		
	}
	//-----------------------------------------------------------

	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Request page (Librarian View Request Page)
	------------------------------------------------------------*/
	@RequestMapping("request")
	public String requestBook(Model m,@ModelAttribute("obj") BooksInventory inventory)
	{
		
		BookTransactions transactions = new BookTransactions();
		String msg= null;
		String reqstatus = service.placerequest(transactions,inventory);
		m.addAttribute("msg",reqstatus);
		return "userViewBooks";
	}
	//------------------------------------------------------------

	
	
	
	/*------------------------------------------------------------
	Method to go to Librarian's View Request page (Librarian View Request Page)
	------------------------------------------------------------*/
	@RequestMapping("successAdd")
	public String addBook(Model m,@ModelAttribute("obj1") BooksInventory inventory)
	{
		
		String target=null;
		int id=service.addBook(inventory);
		if(id>0)
		{
			m.addAttribute("msg","Book stored to Booklist with id:");
			m.addAttribute("id",id);
			target="librarianAddBooks";
		}
		else
		{
			target="contentadmin";
		}
		return target;
	}
	//-----------------------------------------------------------

	
	
	
	
	
	
}
